# The-device
## _Why-this-project?_
[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)
Take an absurd idea: create a 2x6 solenoid matrix, and translate ASCII characters received via serial port into the corresponding Braille dot configuration.

base while building a building. As for our case, we got beautiful eyes and ears, still we don't care. What about those who are differently-abled(those who cannot hear and see). Is the world of technology only for us ?.So started thinking about them!

- Device those change with change in incomming ASCII signal
- Pull and puch make them sense things easy !

## Features

- Uses software to convert ASCII to Braille as arduino signals

## Tech
Most of the contents are open source 
- [ArduinoCode] - Made on them
- [markdown_it ] - Markdown parser done right. Fast and easy to extend.
- [audrino] - For harware implementation

# Installation/Operation
With the solenoids arranged in a 3x2 pack as illustrated (each solenoid was individually wrapped in insulating tape, then again in rows and in a single block), the objective would be to have the core of each solenoid pop out /stick out if its respective point is activated. And that would work egregiously with *real* push-pull solenoids, that would pop out decidedly then pop in as soon as inactivated.

In fact, with the illustrated circuit and components, and with everything powered at 5V, even with separate power supplies the solenoids barely move (unless power supplies are set at an higher voltage... that may be unsafe!) but, with the thumb's pad gently pressed on the tips of the pistons, one may anyway perceive which tips are being rised and which tips are motionless. If one piston disengages and is ejected, it must be clicked in again: another drawback of this suboptimal equipment.

## Tools/Components

>Fairchild semiconductor 1n4004. -1N4007 – High Voltage, High Current Rated Diode ×	6	

>4415447 Resistor 220 ohm ×	6	

>Solenoid, 5V, push-pull ×	6	

>2N3904 NPN transistor ×	6	

>Ph a000066 iso (1) ztbmubhmho	

>Arduino UNO

![image](https://github.com/Deosaju/Letters-Those-Speak/blob/main/Arduino-Code-base/Digital_Print.jpg)
## Development

Want to contribute? Great!
Anybody that may be interested in improving this project to share a refined version of the circuit as soon as available, for everybody to see.

Thanks for the attention!

## Problems

1) I would have needed push-pull solenoids,Real push-pull solenoids have the extraordinary advantage that they snap back in their default position as soon as the current is removed - having bought on ebay the cheap, push-only solenoids described here
2) arduino parts and componets can be made much better !
3) Can be made small( As to size of finger Tip) ,making 8 same combinations helps in reading things faster 
## License

MIT

**Free Hardware , develop on your on !**
