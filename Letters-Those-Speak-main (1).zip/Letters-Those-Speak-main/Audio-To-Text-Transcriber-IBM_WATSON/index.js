var transcribe = require('./transcriber.js');

module.exports = transcribe;
