keep.md added to that when packaging in nwjs folder structure is kept.
it seems to ignore .keep
