# Letter's-Those-Speak
## _Why-this-project?_
[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

Online classes are boring! (not for all), so we feel lazy to attend or we won't hear the basic concepts taken. Missing classes are like forgetting to put 



base while building a building. As for our case, we got beautiful eyes and ears, still we don't care. What about those who are differently-abled(those who cannot hear and see). Is the world of technology only for us ?.So started thinking about them!

- Internet and digital world for those who are differently-abled
- Never miss a class from today!
- Need cooperation from our self ToOoOO oOoOO!
- 
## Features

- Convert recorded voice to any language and make it precise using ML and natural language processing
- Text to braille a unique translator
- Works with all audio formats
- Just a beginning lot more is coming


## Tech
Most of the contents are open source 
- [JavaScript] - Made on them
- [markdown_it ] - Markdown parser done right. Fast and easy to extend.
- [audrino] - For harware implementation
- [IBM_WATSON] - Voice - to - Text API

# Installation
## Steps/Prerequistives

> Record or download audio of ur choice to translate and make notes 

> [This is one of my choices!](https://www.rev.com/onlinevoicerecorder)

> Check out audio to text (IBM) repo and steps for transcribing are given there

> Give related words and topics talking about so for better results 

> Desktop release is also given! ([ A Prerelease](https://github.com/Deosaju/Letters-Those-Speak/releases))

> Hardware output is currently under development, will be updated when the product is out!

> Check regularly for hardware release 

> If u can make one, I am providing Arduino code here!

## Plugins
Good Chrome extensions available for recording and automated attendance
| Plugin | README |
| ------ | ------ |
| N-bot | [Nbot](https://chrome.google.com/webstore/detail/n-bot-google-meet-online/cpcenjbkciljcgglpgcmghcphjcbkffg/related?hl=en) |
| GitHub | [Inspiration](https://github.com/NithinSGowda/Notes-taker-for-online-classes) |
| Bunk_BOt | [check-This-Lazy-one](https://github.com/sujaysathya/bunk_bot)|

## Development

Want to contribute? Great!

## License

MIT

**Free Software, Hell Yeah!**
